#include<stdio.h>
int lab1(int a, int b) {
	int r3 = 0, r4, r5;
	r4 = 16;
	r5 = r4 - b;
	for(;r5 > 0; r5--) {
		a += a;
		if(a > 65536) a = a - 65536;
	}
	int i;
	for(i = 0; i < b; a += a, i++) {
		if(a > 65536) a = a - 65536;
		if(a > 32767) {
			r3++;
		}
	}
	printf("%d\n", r3);
} 
int lab2(int r1, int r2, int r3) {
	int r4 = 1, r5 = 1;
	int r0, r6, r7;
	for(r3 = r3 - 2; r3 >= 0; r3--) {
		r0 = r1;
		while(1) {
			r6 = r0;
			r6 = r4 - r6;
			if(r6 < 0) {
				r6 = r1;
				r0 = r0 - r6;
				r6 = r4 - r0; 
				break;
			}
			else r0 = r0 + r1;
		}
		r0 = r2;
		while(1) {
			r7 = r0;
			r7 = r5 - r7;
			if(r7 < 0) {
				r7 = r2;
				r0 = r0 - r7;
				r7 = r5 - r0;
				break;
			}
			else r0 = r0 + r2;
		}
		r0 = r6 + r7;
		r4 = r5;
		r5 = r0;
	}
	printf("%d\n", r0);
}
int lab3(char s[], int n) {
	int i;
	char s1;
	int length = 1;
	int temp_length = 1;
	for(i = 0; i < n; i++) {
		if(s[i] == s[i+1]) {
			temp_length++;
			if(temp_length > length) {
				length = temp_length;
				continue;
			}
			continue;
		}
		else{
			temp_length = 1;
			continue;
		}
	}
	printf("%d\n",length);
	return 0;
}
void lab4(int arr[]) {
	int len = 16;
    int i, j;
    int A = 85, B = 75;
    int na = 0, nb = 0;
    for(i = 0 ; i < len - 1 ; i++) {
        int min = i;
        for (j = i + 1; j < len; j++)     
            if (arr[j] < arr[min])    
                min = j;   
        int temp = arr[min];
		arr[min] = arr[i];
		arr[i] = temp; 
    }
	for(i = 0; i < len; i++) {
		printf("%d ", arr[i]);
		if(arr[i] >= A) na++;
		else if(arr[i] >= B && i > 7) nb++;
	}
	printf("\n");
	printf("%d %d \n", na, nb);
}
int main() {
	lab1(13, 3);
	lab1(167, 6);
	lab1(32767, 15);
	lab2(256,123,100);
	lab2(512,456,200);
	lab2(1024,789,300);
	char lab3_1[] = "aabbbc", lab3_2[] = "ZZZZz", lab3_3[] = "aabaaa";
	int lab3_1n = 6, lab3_2n = 5, lab3_3n = 6; 
	lab3(lab3_1, lab3_1n);
	lab3(lab3_2, lab3_2n);
	lab3(lab3_3, lab3_3n);
	int lab4_1[] = {100,95,90,85,80,60,55,50,45,40,35,30,25,20,10,0};
	int lab4_2[] = {95,100,0,50,45,40,80,65,70,75,35,20,25,15,10,90};
	int lab4_3[] = {88,77,66,55,99,33,44,22,11,10,9,98,97,53,57,21};
	lab4(lab4_1);
	lab4(lab4_2);
	lab4(lab4_3);
}
